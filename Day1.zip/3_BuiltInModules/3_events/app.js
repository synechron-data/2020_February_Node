const StringEmitter = require('./StringEmitter');

let sm = new StringEmitter();

// setInterval(function () {
//     var s = sm.getString();
//     console.log(s);
// }, 2000);

// sm.pushString(function(s){
//     console.log(s);
// });

sm.on("data", function (s) {
    console.log("S1 - ", s);
});

var cnt = 0;
function S2(s) {
    ++cnt;
    console.log("S2 - ", s.toUpperCase());
    if (cnt > 2) {
        sm.removeListener('data', S2);
    }
}

sm.on("data", S2);