const readline = require('readline');
// console.log(readline);

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// rl.question("Enter a number: ", (n1) => {
//     console.log("You entered: ", n1);
//     rl.close();
// });

// console.log("-------------- Last Line ---------------");

// rl.question("Enter a number: ", (n1) => {
//     let num1 = parseInt(n1);
//     rl.question("Enter a number: ", (n2) => {
//         let num2 = parseInt(n2);
//         let sum = num1 + num2;
//         console.log("Result is: ", sum);
//         rl.close();
//     });
// });

function enterNumberOne() {
    return new Promise((resolve) => {
        rl.question("Enter a number: ", (n1) => {
            let num1 = parseInt(n1);
            resolve(num1);
        });
    })
}

function enterNumberTwo(num1) {
    return new Promise((resolve) => {
        rl.question("Enter a number: ", (n2) => {
            let num2 = parseInt(n2);
            resolve([num1, num2]);
        });
    })
}

function add([n1, n2]) {
    var sum = n1 + n2;
    console.log("Result is: ", sum);
    rl.close();
}

enterNumberOne().then(enterNumberTwo).then(add);

