class Logger {
    log(m){
        console.log(m + ", Logged using Logger Class log function");
    }
}

module.exports = Logger;