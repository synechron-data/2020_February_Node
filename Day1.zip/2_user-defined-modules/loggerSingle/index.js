const Logger = require('./Logger');

let logger;

module.exports.getLogger = function(){
    if(!logger)
        logger = new Logger();

    return logger;
}