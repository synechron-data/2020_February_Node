// const lib = require('./lib.js');
// // console.log(lib);
// console.log(lib.firstname);
// console.log(lib.lastname);
// lib.log("Hi from App");

// const { log } = require('./lib.js');
// log("Hi from App");

// const lib1 = require('./lib.js');
// const lib2 = require('./lib.js');

// console.log(lib1);
// console.log(lib2);
// console.log(lib1 === lib2);

// const lib = require('./lib.js');

// var e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const logger1 = require('./logger1.js');
// const logger1 = require('./logger');

const loggerSingle = require('./loggerSingle');
let l1 = loggerSingle.getLogger();
// l1.log("Hi from App...");

let l2 = loggerSingle.getLogger();
console.log(l1 === l2);