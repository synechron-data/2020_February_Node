const da = require('../data-access');

exports.getUsers = function (req, res, next) {
    da.getAllUsers().then((result) => {
        res.json({ data: result, message: "Success, Getting Users" });
    }, (err) => { 
        res.json({ data: [], message: "Error, Getting Users" });
    });
}

exports.deleteUser = function (req, res, next) {
    da.deleteUser(req.params.userid).then((result) => {
        res.json({ data: [], message: "Success, Deleting Users" });
    }, (err) => { 
        res.json({ data: [], message: "Error, Deleting Users" });
    });
}