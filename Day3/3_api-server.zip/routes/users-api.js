var express = require('express');
var router = express.Router();

const userApiCtrl = require('../controllers/user-api-controller');
const accCtrl = require('../controllers/account-controller');

// Enabling CORS
router.use(function (req, res, next) {
    // update * to match the domain you will make the request from
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

router.use(accCtrl.validateToken);

router.get('/', userApiCtrl.getUsers);

router.delete('/:userid', userApiCtrl.deleteUser);

module.exports = router;